## New feature request (change this to your new feature request title)

## What's your idea?: Explain your idea on your new feature request

## Why would this be awesome? Explain why this will be a great feature to add

## Description:
Write a description about your new feature request

## How would this improve my website? Tell me about how this new feature can improve my website?

## Use case:
Write a use case for this feature request.
Priorty:
Write your priority about this feature.

labels: feature request, priority